
abstract class counterStates{}
class counterInitialState extends counterStates{}
class counterPlusState extends counterStates{}
class counterMinusState extends counterStates{}