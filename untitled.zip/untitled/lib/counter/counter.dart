import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/counter/cubit.dart';
import 'package:untitled/counter/states.dart';
class CounterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create:(BuildContext context)=>counterCubit() ,
      child: BlocConsumer<counterCubit, counterStates>(
        listener:(context,state){} ,
        builder: (context,state) {
          return Scaffold(
            appBar: AppBar(
              title: const Text('counter'),
            ),
            body: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(onPressed: () {
                      counterCubit.get(context).plus();
                    }, child: const Text('Plus',
                      style: TextStyle(
                          fontSize: 20
                      ),
                    )),
                    const SizedBox(
                      width: 10,
                    ),

                    CircleAvatar(
                      radius: 15,
                      child: Text('${counterCubit.get(context).counter}',
                        style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    TextButton(onPressed: () {
                      counterCubit.get(context).minus();
                    }, child: const Text('Minus',
                      style: TextStyle(
                          fontSize: 20
                      ),
                    )),
                  ],
                ),
              ),
            ),
          );
        })); }
}
