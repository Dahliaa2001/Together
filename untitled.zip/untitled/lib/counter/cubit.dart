import 'package:bloc/bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/counter/states.dart';
class counterCubit extends Cubit<counterStates>
{
  counterCubit() : super(counterInitialState());
  static counterCubit get(context) => BlocProvider.of(context);
  int counter=1;
  void minus(){
    counter--;
    emit(counterMinusState());
  }
  void plus(){
    counter++;
    emit(counterPlusState());
  }
}