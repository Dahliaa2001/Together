import 'dart:math';
import 'package:flutter/material.dart';
import 'package:untitled/modules/bmi/bmi_result.dart';
class  BMIscreen extends StatefulWidget {

  @override
  _BMIscreenState createState() => _BMIscreenState();
}

class _BMIscreenState extends State<BMIscreen> {
 bool isMale=true;
 double Height=120;
 int Weight=40;
 int Age=20;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI',
        ),
      ),
      body:

          Column(
            children: [

              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                  children: [

                Expanded(

                    child:
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: 
                          GestureDetector(
                            onTap: (){
setState(() {
  isMale=true;
});
                            },
                            child: Container(
                                decoration: BoxDecoration(
                                  color:isMale ? Colors.blue:Colors.grey,
                                  borderRadius: BorderRadius.circular(5)
                                ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                     Image(image: AssetImage('images/male-gender.png')),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Text('Male',
                                      style: TextStyle(
                                        fontSize: 30,
                                        color: Colors.black,
                                      ),
                                      )
                                    ],
                                  ),
                                ),
                          ),
                        ),
                ),
                Expanded(
                      child:
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: GestureDetector(
                          onTap: (){
setState(() {
  isMale=false;
});
                          },
                          child: Container(

                              decoration: BoxDecoration(
                                  color:!isMale ? Colors.blue:Colors.grey,
                                borderRadius: BorderRadius.circular(5)
                              ),

                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                  
                                    Image(image: AssetImage('images/female.png')),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    Text('Female',
                                      style: TextStyle(
                                        fontSize: 30,
                                        color: Colors.black,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                        ),
                      ),
                )
           ]   ),

            const SizedBox(
              height: 10,
            ),
Column(
  children: [
        Container(

      width: double.infinity,

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
      ),
      child: const Text('Height',
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 30,
        fontWeight: FontWeight.bold,
        color: Colors.black
      ),
      ),
    ),

              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text('${Height.round()}',
                  style: const TextStyle(
                    fontSize: 50,
                    fontWeight: FontWeight.bold,
                    color: Colors.black
                  ),),
                  const SizedBox(
                    height: 5,
                  ),
                  const Text('CM',
                    style: TextStyle(
                        fontSize: 20,
                        color: Colors.black
                    ),)
                ],
              ),
              Slider(value: Height,
               max: 220,
                  min: 80,

                  onChanged: (value){
                    setState(() {
                      Height=value;
                    });
                print(value.round());
                  }),
const SizedBox(
  height: 20,
),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                        Expanded(
                        child:
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius:BorderRadius.circular(5),
                              color: Colors.grey,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children:[
const Text('Age',
    style: TextStyle(
      fontSize: 30,
      fontWeight: FontWeight.bold,
      color: Colors.black
    ),
),
                                Text('$Age',
                                  style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black
                                  ),
                                ),
                                Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    FloatingActionButton(onPressed:() {
                                      setState(() {
                                        Age--;
                                      });

                                    },
                                      mini: true,
                                    child:
                                    const Icon(
    Icons.remove
    )
                                    ,),
                                    FloatingActionButton(onPressed:() {
                                      setState(() {
                                        Age++;
                                      });

                                    },
                                      mini: true,
                                      child:
                                      const Icon(
                                          Icons.add
                                      )
                                      ,)
                                  ],
                                )
                            ]),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.grey
                            ),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children:[
                                  const Text('Weight',
                                    style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black
                                    ),
                                  ),
                                  Text('${Weight}',
                                    style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black
                                    ),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      FloatingActionButton(onPressed:() {
                                        setState(() {
                                          Weight--;
                                        });

                                      },
                                        mini: true,
                                        child:
                                        const Icon(
                                            Icons.remove
                                        )
                                        ,),
                                      FloatingActionButton(onPressed:() {
                                        setState(() {
                                          Weight++;
                                        });

                                      },
                                        mini: true,
                                        child:
                                        const Icon(
                                            Icons.add
                                        )
                                        ,)
                                    ],
                                  )
                                ]),
                          ),
                        ),
                      ),
                  ]  )  ,

                ),

            ],

      ) ,
        const SizedBox(
          height: 15,
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Container(
            width:double.infinity ,
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(5)
            ),
            child:
      MaterialButton(onPressed: (){
        double result=Weight/pow(Height/100,2);
        print(result.round());
        Navigator.push(
            context,
            MaterialPageRoute
          (builder:
            (context)=>BMIresult(isMale: isMale, Age: Age, result: result)

        ),
        );
      },
      child:
      const Text(
          'Calculate',
      style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
          color: Colors.black
      ),
          textAlign: TextAlign.center,
      ),
      )
          ),
        )    ]),
              );
  }
}
