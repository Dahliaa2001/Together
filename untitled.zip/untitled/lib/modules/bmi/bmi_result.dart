import 'dart:math';

import 'package:flutter/material.dart';
import 'package:untitled/modules/bmi/bmi_result.dart';
class BMIresult extends StatelessWidget {
  final double result;
  final bool isMale;
  final int Age;

  BMIresult({
    @required this.isMale,
   @required this.Age,
   @required this.result,
});

  @override
  Widget build(BuildContext context) {
    return
        Scaffold(
            appBar: AppBar(
              title:Text(
                  'BMI Result'
              ),
            ),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Gender:${isMale ?'male':'female'}',
                    style: TextStyle(
                        fontSize: 40,
                        color: Colors.blue,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                  Text('Result:$result',
                    style: TextStyle(
                        fontSize: 40,
                        color: Colors.blue,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                  Text('Age:$Age',
                    style: TextStyle(
                        fontSize: 40,
                        color: Colors.blue,
                        fontWeight: FontWeight.bold
                    ),
                  )
                ],
              ),
            )



    );
  }
}
