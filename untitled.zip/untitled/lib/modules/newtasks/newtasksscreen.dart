import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/shared/components/components.dart';
import 'package:untitled/shared/cubit/states.dart';
import '../../shared/cubit/cubit.dart';
class NewTasksScreen extends StatelessWidget {
  get tasks => null;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TodoCubit,TodoStates>(
      listener: (context,state){},
      builder: (context,state) {
        return taskBuilder(tasks: tasks);
    }
    )
    ;
  }
}
