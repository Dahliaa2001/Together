import 'package:flutter/material.dart';
import 'package:untitled/shared/components/components.dart';
class LoginScreen extends StatelessWidget {
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var formkey=GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: formkey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'login',
                style: TextStyle(
                    fontSize: 40,
                    color: Colors.black,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                height: 20,
              ),
              TextFormField(
                controller: emailController,
                decoration: const InputDecoration(
                    labelText: 'Email Address',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email)),
                keyboardType: TextInputType.emailAddress,
                onFieldSubmitted: (value) {
                  print(value);
                },
              ),
              const SizedBox(
                height: 15,
              ),
              TextFormField(
                controller: passwordController,
                decoration: const InputDecoration(
                    labelText: 'Password',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock),
                    suffixIcon: Icon(Icons.remove_red_eye)),
                keyboardType: TextInputType.visiblePassword,
                obscureText: true,
                onFieldSubmitted: (pass) {
                  print(pass);
                },
                onChanged: (String value){
                  print(value);
                },
                validator: (value){
                  if(value.isEmpty){
                    return 'password must not be empty';
                  }
                  return null;
                },
              ),
              const SizedBox(
                height: 15,
              ),
              Container(
                  width: double.infinity,
                  color: Colors.blue,
                  child:
              defaulButton(width: double.infinity, Color: Colors.blue, function:(){
                if(formkey.currentState.validate()){
                  print(emailController.text);
                  print(passwordController.text);
                }
              }, text: 'login')
              ),
              const SizedBox(
                height: 15,
              ),
              Container(
                  child:
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Don\'t have an account?'),
                      TextButton(onPressed:  (){},child: const Text('Sign up'),)
                    ],
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
