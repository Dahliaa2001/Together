import 'package:conditional_builder/conditional_builder.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:untitled/shared/components/components.dart';
import 'package:untitled/shared/cubit/cubit.dart';
import 'package:untitled/shared/cubit/states.dart';
class HomeLayout extends StatelessWidget {
  @override
 var scaffoldKey=GlobalKey<ScaffoldState>();
 bool isBottomSheetShown=false;
 IconData fabIcon=Icons.edit;
 var titleController=TextEditingController();
 var timeController=TextEditingController();
 var dateController=TextEditingController();
 var formKey=GlobalKey<FormState>();
 bool isEmpty=true;
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context)=>TodoCubit()..createDatabase(),
      child: BlocConsumer<TodoCubit,TodoStates>(
     listener: (context,state){
       if (state is TodoInsertDatabaseState){
         Navigator.pop(context);
       }
     },
        builder: (context,state){
       return   Scaffold(
            key: scaffoldKey,
            appBar: AppBar(
              title:Text(TodoCubit.get(context).titles[TodoCubit.get(context).currentIndex],
                style: const TextStyle(
                  fontSize: 25,
                ),
              ),
            ),
            floatingActionButton: FloatingActionButton(
              child: Icon(TodoCubit.get(context).fabIcon),
                onPressed:(){
              if(isBottomSheetShown){
          if(formKey.currentState.validate()){
          TodoCubit.get(context).insertToDatabase(
          time: timeController.text, title: titleController.text,date: dateController.text
          );}
              }
          else
          {
          scaffoldKey.currentState.showBottomSheet((context) =>
          Container(
          color: Colors.white,
          padding:const EdgeInsets.all(20) ,
           child: Form(
            key: formKey,
          child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
          defaultFormField(controller: titleController,
          label: 'Task Title',
          prefix: Icons.title,
          type: TextInputType.text,
          validate:(String value){
           if (value.isEmpty) {
             return 'title must not be empty';
          }
          else {
            return null;
          }},
          ),
          const SizedBox(
          height: 15,
          ),
          defaultFormField(controller: timeController,
          type: TextInputType.datetime,
          validate:(String value){
          if (value=null) {
          return 'time must not be empty';
          }
          else {
          return null;
          }
          },
          label: 'Task Time',
          prefix: Icons.watch_later_outlined,
          onTap: (){
          showTimePicker(context: context, initialTime:TimeOfDay.now(),
          ).then((value){
          timeController.text=value.format(context).toString();
          });
          },
          ),
          const SizedBox(
          height: 15,
          ),
          defaultFormField(controller: dateController,
          type: TextInputType.datetime,
          validate:(String value){
          if (value.isEmpty) {
          return 'date must not be empty';
          }
          else {
          return null;
          }
          },
          label: 'Task Date',
          prefix: Icons.calendar_today,
          onTap: (){
           showDatePicker(context: context,
               initialDate: DateTime.now(),
               firstDate: DateTime.now(),
               lastDate: DateTime.parse('2023-05-03')).then((value){
          dateController.text=DateFormat.yMMMd().format(value);
            print(DateFormat.yMMMd().format(value));
          });
          })
          ],
          ),
          ),
          ),
          elevation: 20,
          ).closed.then((value) => (){
            TodoCubit.get(context).changeBottomSheetState(
                isShow: false,
                icon: Icons.edit
            );
          });
         TodoCubit.get(context).changeBottomSheetState(
             isShow: true,
             icon: Icons.add
         );
               }}),
          bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: TodoCubit.get(context).currentIndex,
          onTap:(index){
          TodoCubit.get(context).changeIndex(index);
          }
         ,
          items: const [
          BottomNavigationBarItem(icon: Icon(
          Icons.menu,
          ),
          label: 'Tasks',
          ),
          BottomNavigationBarItem(icon: Icon(
          Icons.check_circle_outline,
          ),
          label: 'Done',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.archive_outlined,),
          label: 'Archive',
          )
          ]),
                body: ConditionalBuilder(condition:  state is! TodoGetDataLoadingFromDatabaseState,
          builder: (context)=>TodoCubit.get(context).screens[TodoCubit.get(context).currentIndex],
          fallback: (context)=>const Center(child:CircularProgressIndicator() )
     ),
              );
  }
          ));
  }
}

