import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:const Icon(
          Icons.menu,
        ),
        title: const Text(
          'VACOST',
        ),
        actions: [
          IconButton(
            onPressed: () {
              print('notification clicked');
            },
            icon: Icon(Icons.notification_important),
          ),
        ],
        centerTitle: true,
      ),
      body: Container(
        width: double.infinity,
        color: Colors.blue,
        child: (SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                    child: Container(
                        color: const Color.fromARGB(255, 223, 9, 9),
                        child: (const Text('Available vaccines',
                         style: TextStyle(
                                color: Colors.white,
                                fontSize: 30.0,
                                backgroundColor:
                            Color.fromARGB(255, 223, 9, 9)))))),
                Expanded(
                    child: Container(
                        color: const Color.fromARGB(255, 223, 9, 9),
                        child: ( const Text('Quantity',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 30.0,
                                backgroundColor:
                                Color.fromARGB(255, 223, 9, 9)))))),
              ],
            ))),
      ),
    );
  }
}
