import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:untitled/shared/cubit/states.dart';
import '../../modules/archivedtasks/archievedtasks.dart';
import '../../modules/donetasks/donetasksscreen.dart';
import '../../modules/newtasks/newtasksscreen.dart';

class TodoCubit extends Cubit<TodoStates>{
  TodoCubit(): super(TodoInitialState());
  static TodoCubit get(context)=>BlocProvider.of(context);
  int currentIndex=0;
  Database dataBase;
  List<Widget> screens=
  [
    NewTasksScreen(),
    DoneTasksScreen(),
    ArchivedTasksScreen(),
  ];
  List<String> titles=
  [
    'New Tasks',
    'Done Tasks',
    'Archieved Tasks'
  ];

  List<Map> newtasks=[];
  List<Map> archievedtasks=[];
  List<Map> donetasks=[];
  void changeIndex(int index) {
    currentIndex=index;
    emit(TodoChangeBottomNavBarState());
  }

  void createDatabase(){
    openDatabase('todo.db',
        version: 1,
        onCreate:(dataBase,version)async {
          print('dataBase created');
          await dataBase.execute('CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT,date TEXT,time TEXT,status TEXT)');
        },
        onOpen: (dataBase) {
getDataFromDataBase(dataBase);
        }).then((value){
          value=dataBase;
          emit(TodoCreateDatabaseState());
    });
  }

  insertToDatabase({
    @required title,
    @required time,
    @required date
  })async{
    await dataBase.transaction((txn)async {
      txn.rawInsert('INSERT INTO tasks(title,time,date,status)VALUES("$title","$time","$date","new task")').then(
              (value){
            print('$value inserted successfully');
            emit(TodoInsertDatabaseState());
            getDataFromDataBase(dataBase);
      });
    });
  }

  void getDataFromDataBase(dataBase){
    newtasks[null];
    archievedtasks[null];
    donetasks[null];
    emit(TodoGetDataLoadingFromDatabaseState());
     dataBase.rawQuery('SELECT * FROM tasks').then((value)  {
value.forEach((element){
  if (element['status']=='new'){
    newtasks.add(element);
  }
  else if (element['status']=='done'){
    donetasks.add(element);
  }
  else {
    archievedtasks.add(element);
  }
});
       emit(TodoGetDataFromDatabaseState());
     });
  }
 bool isBottomSheetShown=false;
  IconData fabIcon= Icons.edit;

  void changeBottomSheetState({
  @required bool isShow,
    @required IconData icon,
}){
isBottomSheetShown=isShow;
fabIcon=icon;
emit(TodoChangeBottomSheetState());
  }

  Future<int> updateData({
  @required String status,
    @required int id
})async
  {
    return await dataBase.rawUpdate(
        'UPDATE tasks SET status = ?, value=?, WHERE id = ?',
      ['$status','$id']
        ).then((value) {
         getDataFromDataBase(dataBase);
          emit(TodoUpdateDatabaseState());
    });
  }
  void deleteData({
  @required int id
})async
  {
    dataBase.rawDelete('DELETE FROM tasks WHERE id=?',[id]).
    then((value){
      getDataFromDataBase(dataBase);
      emit(TodoDeleteDatabaseState());
    });

}
  }

