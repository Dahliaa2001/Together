abstract class TodoStates {}
class TodoInitialState extends TodoStates{}
class TodoChangeBottomNavBarState extends TodoStates{}
class TodoCreateDatabaseState extends TodoStates{}
class TodoInsertDatabaseState extends TodoStates{}
class TodoGetDataFromDatabaseState extends TodoStates{}
class TodoChangeBottomSheetState extends TodoStates{}
class TodoGetDataLoadingFromDatabaseState extends TodoStates{}
class TodoUpdateDatabaseState extends TodoStates{}
class TodoDeleteDatabaseState extends TodoStates{}

