//base url:
//method(url):
//queries: