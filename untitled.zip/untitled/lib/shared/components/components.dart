import 'package:conditional_builder/conditional_builder.dart';
import 'package:flutter/material.dart';
import 'package:untitled/shared/cubit/cubit.dart';
Widget defaulButton({
   double width =double.infinity,
Color=Colors.blue ,
  @required Function function,
  @required String text,
})=>Container(
    width: width,
    color:Color,
    child: MaterialButton(
        onPressed: () {
         function;
        },
        child: Text(
          text.toUpperCase()
          ,
          style: const TextStyle(color: Colors.white),
        )));
Widget defaultFormField({
  @required TextEditingController controller,
  @required TextInputType type,
  @required validate,
  @required String label,
  @required IconData prefix,
  IconData suffix,
 Function onSubmit,
 Function onPressed,
  Function onTap,
  bool isClickable=true,
 Function onChange,
  Function suffixPressed,
  bool isPassword=false,
})=>TextFormField(
  keyboardType: type,
obscureText: isPassword,
  onFieldSubmitted: onSubmit,
  onTap: onTap,
  enabled: isClickable,
 onChanged: onChange,
  validator: validate,
  controller: controller,
  decoration: InputDecoration(
labelText: label,
    border: const OutlineInputBorder(),
    prefixIcon:Icon(prefix),
  ),
);
Widget buildTaskItem(
    Map model,context
)=> Dismissible(
  key: (model['id']),
  onDismissed: (direction){
    TodoCubit.get(context).deleteData(id: model['id']);
  },
  child:   Padding(
  padding: const EdgeInsets.all(20.0),
  child: Row(
  children: [
   CircleAvatar(
  radius: 35,
  child: Text('${model['time']}'),
  ),
  const SizedBox(
  width: 15,
  ),
  Expanded(
    child:   Column(
    mainAxisSize: MainAxisSize.min,
    children: [
    Text('${model['title']}',
    style: const TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold
    ),
    ),
    Text('${model['date']}',
    style: const TextStyle(
    fontSize: 15,
    color: Colors.grey
    ),
    )
    ],
    ),
  ),
    const SizedBox(
      width: 15,
    ),
    IconButton(onPressed: (){
      TodoCubit.get(context).updateData(status: 'done', id: model['id']);
    }, icon: const Icon(
      Icons.check_box,
      color: Colors.green,
    )),
    IconButton(onPressed: (){
      TodoCubit.get(context).updateData(status: 'archieve', id: model['id']);
    }, icon: const Icon(
        Icons.archive,
      color: Colors.black45,
    ))
  ],
  ),
  ),
);
Widget taskBuilder({
  @required List<Map> tasks
})=>ConditionalBuilder(
condition: tasks.length>0 ,
builder: (context) => ListView.separated(itemBuilder: (context, index)=>
buildTaskItem( TodoCubit.get(context).newtasks[index],context),
separatorBuilder: (context, index)=>
Container(
width: double.infinity,
height:1,
color: Colors.grey[300]
),
itemCount: TodoCubit.get(context).newtasks.length),
fallback:(context) =>Center(
child: Column(
children: const [
Icon(Icons.menu,
size: 100,
color: Colors.grey,
),
Text('No Tasks Yet, Please Add Some Tasks',
style: TextStyle(
fontSize: 16,
fontWeight: FontWeight.bold
),
)
],
),
),
);