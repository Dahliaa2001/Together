import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:untitled/AI%20therapy%20sessions/controller/AIquiz.dart';
class  AIHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(title: const Text('Welcome!',style: TextStyle(fontFamily: "Gabriela",color: Colors.purple),),backgroundColor: HexColor("#D3EEDD"),),
      body: SingleChildScrollView(
          child: Expanded(
          child: Column(children: [
            const Image(image: AssetImage('images/2023-01-06.png')),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8), color: Colors.grey[200],),
                  margin: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
                  child: const Text('Hello buddy!\n\n feel comfortable to attempt this simulated AI therapy session'
                      ' check this info to know more about our  program'
                      ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                  fontSize: 25,
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8),  color: Colors.grey[200],),
                  margin: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
                  child: const Text(
                      ' Our aim is an alignment for the mental therapy to diagnose the '
                      'illness level and then decides the amount of its medication.'
                      ' Based on many mode phases and cumulative analysis for the patient.'
                     ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8), color: Colors.grey[200],),
                  margin: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
                  child: const Text(
                      'Before you get started here are some tips:'
                      ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8),color: Colors.grey[200],),

                  child: const Text(
                      '1. You will find 20 questions that you are going to have to answer all'
                      ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8),   color: Colors.grey[200],),

                  child: const Text(
                      '2. Answers will be viwed in a slider scaled from 0 to 10 '
                      'and from 0 to 1 make sure that you dragged all of them'
                      ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8), color: Colors.grey[200],),

                  child: const Text(
                      '3. As for some validation, you can click on the button next to each '
                      'slider after confirming your answer, it will be as a reminder in case '
                      'you forgot to confirm some answers'
                      ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8),  color: Colors.grey[200],),
                  child: const Text(
                      '4. Finished all answers already? click on the varification button in the bottom right of the screen '
                      'then you will get your result as a prediction of the illness level\n'
                      'wish ya all luck xd'
                      ,style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  decoration: BoxDecoration(borderRadius:BorderRadius.circular(8), color: Colors.grey[200], ),
                  child: const Text(
                      'What are you waiting for? lets get started',style:
                  TextStyle(color: Colors.purple,fontFamily: "Gabriela",
                      fontSize: 25
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Center(
              child: MaterialButton(
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Ques()));
                },
                color: HexColor("#D3EEDD"),
                child: const Text('Shall we start?',
                style:TextStyle(
                  color: Colors.purple,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Gabriela"
                ) ,),),
            )
            ],),
        ),
      ),
    );
  }
}
