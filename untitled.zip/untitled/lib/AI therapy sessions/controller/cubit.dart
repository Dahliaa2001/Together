import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/AI%20therapy%20sessions/controller/states.dart';

class therapyCubit extends Cubit<therapySessionsState>{
  therapyCubit():super(therapyInitialState());
  static therapyCubit get(context)=>BlocProvider.of(context);
}