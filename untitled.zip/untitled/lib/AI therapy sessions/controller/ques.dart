import 'package:flutter/material.dart';
import 'package:untitled/remote/dio_helper.dart';
class AIResult extends StatelessWidget {


  @override
  Future result=dioHelper.getData(url: '/model', query: {'Y_model'});
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

      ),
      body: Center(
        child: Container(
          child: Text(''),
        ),
      ),
    );
  }
}
