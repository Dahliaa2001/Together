class questionmodel{
  int id,answer;
  String question;
  List<String> options;
  questionmodel({
 this.id,
 this.answer,
    this.question,
    this.options
});
}
