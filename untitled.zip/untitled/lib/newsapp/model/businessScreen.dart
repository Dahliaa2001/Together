import 'package:flutter/material.dart';

class businessScreen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Text('BUSINESS',
        style: TextStyle(
          fontSize: 30,
          fontWeight: FontWeight.bold
        ),),
      ),
    );
  }
}
