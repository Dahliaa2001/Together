import 'package:flutter/material.dart';

class sportsScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Text('SPORTS', style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold
        ),),
      ),
    );
  }
}
