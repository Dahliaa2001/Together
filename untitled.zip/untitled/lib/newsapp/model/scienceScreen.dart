import 'package:flutter/material.dart';

class scienceScreen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Text('SCIENCE', style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold
        ),),
      ),
    );
  }
}
