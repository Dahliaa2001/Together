import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/newsapp/cubit/cubit.dart';
import 'package:untitled/newsapp/cubit/states.dart';

class newsLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create:(BuildContext context)=> newsCubit()..getBusiness(),
      child: BlocConsumer<newsCubit,newsStates>(
        listener:(context,state){} ,
        builder:(context,state) {
          var cubit=newsCubit.get(context);
    return Scaffold(
    appBar: AppBar(
    title: Text('NEWS APP'),
      actions:[
        IconButton(icon: const Icon(Icons.search),
          onPressed: (){

          },)
      ]
    ),
    body: cubit.screens[cubit.currentIndex],
    bottomNavigationBar: BottomNavigationBar(
    currentIndex: cubit.currentIndex,
      onTap: (index){
      cubit.changeBottomNavBar(index);
      },
      items: cubit.bottomItems,
    ),
    );
    }
    ));
  }
}
