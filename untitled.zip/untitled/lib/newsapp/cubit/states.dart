abstract class newsStates{}
class newsInitialState extends newsStates{}
class newsChangeBottomNavBarState extends newsStates{}
class newsLoadingState extends newsStates{}
class newsGetBusinessSuccessState extends newsStates{}
class newsGetBusinessErrorState extends newsStates{}