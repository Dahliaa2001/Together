import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/newsapp/cubit/states.dart';
import 'package:untitled/newsapp/model/scienceScreen.dart';
import 'package:untitled/newsapp/model/settingsScreen.dart';
import 'package:untitled/remote/dio_helper.dart';

import '../model/businessScreen.dart';
import '../model/sportsScreen.dart';

class newsCubit extends Cubit<newsStates>{
  newsCubit(): super(newsInitialState());
  static newsCubit get(context)=>BlocProvider.of(context);
int currentIndex=0;
List<BottomNavigationBarItem> bottomItems=[
  const BottomNavigationBarItem(icon:
  Icon(Icons.business),
  label: 'Business'
  ),
  const BottomNavigationBarItem(icon:
  Icon(Icons.sports),
      label: 'Sports'
  ),
  const BottomNavigationBarItem(icon:
  Icon(Icons.science),
      label: 'Science'
  ),
  const BottomNavigationBarItem(icon:
  Icon(Icons.settings),
      label: 'Settings'
  )
];
void changeBottomNavBar(int index){
  currentIndex=index;
  emit(newsChangeBottomNavBarState());
}
List<Widget> screens=[
  businessScreen(),
  sportsScreen(),
  scienceScreen(),
  settingsScreen(),

];
List<dynamic> business=[];
void getBusiness(){
  emit(newsLoadingState());
  dioHelper.getData(
url: 'v2/top-headlines',
    query: {
  'country':'eg',
      'category':'business'
    }
  ).then((value) {
 business=value.data['articles'];
 emit(newsGetBusinessSuccessState());
  //  print(value.data['articles'][0]['title']);
  }).catchError((error){
    emit(newsGetBusinessErrorState());
    print(error.toString());
  });
}
}