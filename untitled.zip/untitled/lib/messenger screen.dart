import 'package:flutter/material.dart';
class MessengerScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0.0,
          title:
          Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: NetworkImage(
                      'https://scontent.fcai19-3.fna.fbcdn.net/v/t39.30808-6/298172782_617419239951072_229116441205061604_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=vzyGzn0Z6MQAX-_r_AI&_nc_ht=scontent.fcai19-3.fna&oh=00_AT_HhWbBMVxUFpYFGtFYttVYA02_Jqv1YjCvNrdEPlkgRg&oe=63586C96'),
                ),
                SizedBox(
                  width: 15,
                ),
                Text('chats',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                  ),
                )
              ]
          ),
          actions: [
            IconButton(
                icon:
                CircleAvatar(
                  backgroundColor: Colors.blue,
                  radius: 15,
                  child: Icon(
                    Icons.camera_alt,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                onPressed: () {}),
            IconButton(
                icon:
                CircleAvatar(
                  backgroundColor: Colors.blue,
                  radius: 15,
                  child: Icon(
                    Icons.edit,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                onPressed: () {})
          ]
      ),

      body:

      Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        color: Colors.grey[100]),
                    child: Row(

                        children: [

                          Icon(
                            Icons.search,
                            color: Colors.black,
                            size: 16,
                          ),
                          SizedBox(
                            width: 15,
                          ),

                          Text
                            ('search',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                            ),
                          ),

                        ]
                    ),

                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        Container(
                          width: 60,
                          child: Column(
                            children: [
                              Stack(
                                  alignment: AlignmentDirectional.bottomEnd,
                                  children: [CircleAvatar(
                                    radius: 30,
                                    backgroundImage: NetworkImage(
                                        'https://scontent-hbe1-1.xx.fbcdn.net/v/t39.30808-6/292078789_768016497565250_6231983330153531775_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=iiiqLu5JZm4AX9pnmco&_nc_ht=scontent-hbe1-1.xx&oh=00_AT-DH0vcm-CBDWjtmMnQ83LIan5z5lkJL3pl0HtS3sm4ig&oe=6357EA1E'),
                                  ),
                                    Padding(
                                      padding: const EdgeInsetsDirectional.only(
                                        start: 3,
                                        top: 3,
                                      ),
                                      child: CircleAvatar(
                                        radius: 8,
                                        backgroundColor: Colors.white,
                                      ),
                                    ),
                                    CircleAvatar(
                                      radius: 7,
                                      backgroundColor: Colors.green,
                                    )
                                  ]

                              ),
                              SizedBox(
                                height: 6,
                              ),
                              Text('Yasmeen Elezaby',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,)
                            ],),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          width: 60,
                          child: Column(
                            children: [
                              Stack(
                                  alignment: AlignmentDirectional.bottomEnd,
                                  children: [CircleAvatar(
                                    radius: 30,
                                    backgroundImage: NetworkImage(
                                        'https://scontent-hbe1-1.xx.fbcdn.net/v/t1.6435-9/56547305_1231572150344694_7994300362657890304_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=Kh5vpfC1ZNcAX__9haj&_nc_ht=scontent-hbe1-1.xx&oh=00_AT_bDmNanF7lzqEQEsb70KUAQHfxSXUN9hzLSmb2ongCwg&oe=63783AFC'),
                                  ),
                                    Padding(
                                      padding: const EdgeInsetsDirectional.only(
                                        start: 3,
                                        top: 3,
                                      ),
                                      child: CircleAvatar(
                                        radius: 8,
                                        backgroundColor: Colors.white,
                                      ),
                                    ),
                                    CircleAvatar(
                                      radius: 7,
                                      backgroundColor: Colors.green,
                                    )
                                  ]

                              ),
                              SizedBox(
                                height: 6,
                              ),
                              Text('Hajar Farhat',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,)
                            ],),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  ),
                ),
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [ Stack(
                            alignment: AlignmentDirectional.bottomEnd,
                            children: [CircleAvatar(
                              radius: 30,
                              backgroundImage: NetworkImage(
                                  'https://scontent-hbe1-1.xx.fbcdn.net/v/t1.6435-9/56547305_1231572150344694_7994300362657890304_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=Kh5vpfC1ZNcAX__9haj&_nc_ht=scontent-hbe1-1.xx&oh=00_AT_bDmNanF7lzqEQEsb70KUAQHfxSXUN9hzLSmb2ongCwg&oe=63783AFC'),
                            ),
                              Padding(
                                padding: const EdgeInsetsDirectional.only(
                                  start: 3,
                                  top: 3,
                                ),
                                child: CircleAvatar(
                                  radius: 8,
                                  backgroundColor: Colors.white,
                                ),
                              ),
                              CircleAvatar(
                                radius: 7,
                                backgroundColor: Colors.green,
                              )
                            ]

                        ),
                          SizedBox(
                            width: 15,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(

                                  children: [
                                    Container(
                                      width: 60,
                                      child: Text('Hajar Farhat',
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,),
                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 3,
                                ),
                                Row(children: [
                                  Text('في سكشن بكرا؟',
                                    maxLines: 2,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text('9:18')
                                ]
                                )
                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                            children: [ Stack(
                                alignment: AlignmentDirectional.bottomEnd,
                                children: [CircleAvatar(
                                  radius: 30,
                                  backgroundImage: NetworkImage(
                                      'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Black_flag.svg/1125px-Black_flag.svg.png'),
                                ),
                                  Padding(
                                    padding: const EdgeInsetsDirectional.only(
                                      start: 3,
                                      top: 3,
                                    ),
                                    child: CircleAvatar(
                                      radius: 8,
                                      backgroundColor: Colors.white,
                                    ),
                                  ),
                                  CircleAvatar(
                                    radius: 7,
                                    backgroundColor: Colors.green,
                                  )
                                ]

                            ),
                              SizedBox(
                                width: 15,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(

                                      children: [
                                        Container(
                                          width: 60,
                                          child: Text('Mennah Hamed',
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Text('هطخك',
                                          maxLines: 2,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text('7:45')
                                      ],
                                    )
                                  ],
                                ),
                              ),


                            ])
                    )
                  ],


                ), Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [ Stack(
                        alignment: AlignmentDirectional.bottomEnd,
                        children: [CircleAvatar(
                          radius: 30,
                          backgroundImage: NetworkImage(
                              'https://scontent-hbe1-1.xx.fbcdn.net/v/t39.30808-6/292078789_768016497565250_6231983330153531775_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=iiiqLu5JZm4AX9pnmco&_nc_ht=scontent-hbe1-1.xx&oh=00_AT-DH0vcm-CBDWjtmMnQ83LIan5z5lkJL3pl0HtS3sm4ig&oe=6357EA1E'),
                        ),
                          Padding(
                            padding: const EdgeInsetsDirectional.only(
                              start: 3,
                              top: 3,
                            ),
                            child: CircleAvatar(
                              radius: 8,
                              backgroundColor: Colors.white,
                            ),
                          ),
                          CircleAvatar(
                            radius: 7,
                            backgroundColor: Colors.green,
                          )
                        ]

                    ),
                      SizedBox(
                        width: 15,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(

                              children: [
                                Container(
                                  width: 60,
                                  child: Text('Yasmeen Elezaby',
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 3,
                            ),
                            Row(
                              children: [
                                Text('نلعب لودو؟',
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text('6:30')
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ])
      ),);
  }}