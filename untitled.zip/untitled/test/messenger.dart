import 'package:flutter/material.dart';
class messengerScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white ,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.0,
        title:
        Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundImage: NetworkImage('https://s3.amazonaws.com/external_clips/users/687868/medium/IMG_%D9%A2%D9%A0%D9%A2%D9%A2%D9%A0%D9%A6%D9%A2%D9%A2_%D9%A0%D9%A1%D9%A0%D9%A8%D9%A2%D9%A5.jpg?1658162863'),
              )
            ]
        )
        ,
      ),
    );
  }
}
